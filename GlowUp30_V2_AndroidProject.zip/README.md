# Glow Up 30 — Version 2

A purple/black Android self-care habit tracker for face, teeth, and lips.

Features:
- Cute purple/black dark UI
- 30-day progress
- Streak counter
- Daily 7 PM reminder
- Local progress storage
- Budget product cards
- Reset button
- Android 13+ notification permission

Build:
1. Open this project in Android Studio.
2. Sync Gradle.
3. Build > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk
