package com.example.facecare30day;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    SharedPreferences prefs;
    ProgressBar progressBar;
    TextView progress, streak;
    CheckBox[] checks;
    final String CHANNEL = "glow_reminders";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("glowup", MODE_PRIVATE);
        progressBar = findViewById(R.id.progressBar);
        progress = findViewById(R.id.progress);
        streak = findViewById(R.id.streak);
        checks = new CheckBox[]{findViewById(R.id.face),findViewById(R.id.moisturize),
            findViewById(R.id.sunscreen),findViewById(R.id.teeth),
            findViewById(R.id.floss),findViewById(R.id.lips)};
        load();

        findViewById(R.id.completeDay).setOnClickListener(v -> completeDay());
        findViewById(R.id.reset).setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Reset challenge?").setMessage("Your 30-day progress will be cleared.")
            .setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,w)->reset()).show());
        findViewById(R.id.notify).setOnClickListener(v -> enableReminder());

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 20);
        createChannel();
    }

    void load() {
        for(int i=0;i<checks.length;i++) checks[i].setChecked(prefs.getBoolean("c"+i,false));
        int days=prefs.getInt("days",0), s=prefs.getInt("streak",0);
        progressBar.setProgress(days); progress.setText(days+" / 30");
        streak.setText("🔥 "+s+" day streak");
    }

    void completeDay() {
        for(CheckBox c:checks) if(!c.isChecked()) {
            Toast.makeText(this,"Finish every item first ✨",Toast.LENGTH_SHORT).show(); return;
        }
        int days=Math.min(30,prefs.getInt("days",0)+1);
        int s=prefs.getInt("streak",0)+1;
        SharedPreferences.Editor e=prefs.edit().putInt("days",days).putInt("streak",s);
        for(int i=0;i<checks.length;i++) e.putBoolean("c"+i,false);
        e.apply(); load();
        Toast.makeText(this,days==30?"30 DAYS COMPLETE! 🎉":"Day "+days+" complete! 🔥",Toast.LENGTH_LONG).show();
    }

    void reset() { prefs.edit().clear().apply(); load(); }

    void createChannel() {
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel c=new NotificationChannel(CHANNEL,"Glow Up reminders",
                NotificationManager.IMPORTANCE_DEFAULT);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    void enableReminder() {
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        Intent i=new Intent(this,ReminderReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(this,101,i,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Calendar cal=Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY,19); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0);
        if(cal.before(Calendar.getInstance())) cal.add(Calendar.DAY_OF_YEAR,1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),
            AlarmManager.INTERVAL_DAY,pi);
        Toast.makeText(this,"Daily reminder set for 7:00 PM 🔔",Toast.LENGTH_LONG).show();
    }
}
