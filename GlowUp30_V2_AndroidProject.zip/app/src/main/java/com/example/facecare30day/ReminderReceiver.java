package com.example.facecare30day;
import android.app.*; import android.content.*; import android.os.Build;
public class ReminderReceiver extends BroadcastReceiver {
 public void onReceive(Context c, Intent i) {
  String ch="glow_reminders";
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Glow Up 30 ✨")
   .setContentText("Time for your face, teeth & lip-care routine!")
   .setAutoCancel(true);
  ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(101,b.build());
 }
}
