package com.glowup.schedule;

import android.app.*; import android.os.*; import android.content.*; import android.graphics.Color;
import android.graphics.drawable.GradientDrawable; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
    LinearLayout content; android.content.SharedPreferences prefs;
    final int PURPLE=Color.rgb(199,125,255), WHITE=Color.WHITE;
    String[][] tasks={
        {"5:00 AM","Wake up + water"},{"5:10 AM","Morning self-care"},{"5:30 AM","Morning workout"},
        {"5:50 AM","Clean up + get dressed"},{"6:10 AM","Breakfast"},{"6:35 AM","Pack + get ready"},
        {"7:15 AM","School"},{"4:00 PM","Home + snack + relax"},{"4:30 PM","Study / homework"},
        {"5:30 PM","Gaming / Roblox recording"},{"6:30 PM","Dinner"},{"7:00 PM","Editing"},
        {"8:00 PM","Evening movement"},{"8:30 PM","Bath"},{"9:00 PM","Evening self-care"},
        {"9:30 PM","Wind down + prepare"},{"10:00 PM","Sleep"}};

    public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("glow",0); home();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},10);}

    TextView t(String s,int n){TextView x=new TextView(this);x.setText(s);x.setTextColor(WHITE);x.setTextSize(n);x.setPadding(16,12,16,12);return x;}
    LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(10,8,10,8);
        GradientDrawable g=new GradientDrawable();g.setColor(Color.rgb(23,16,34));g.setCornerRadius(28);c.setBackground(g);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,8,0,8);c.setLayoutParams(p);return c;}
    void base(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(9,6,18));
        ScrollView s=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(16,18,16,24);s.addView(content);
        root.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    void nav(){LinearLayout n=new LinearLayout(this);String[] a={"Today","Schedule","Study","日本語","Settings"};
        for(String q:a){Button b=new Button(this);b.setText(q);b.setAllCaps(false);b.setOnClickListener(v->{if(q.equals("Today"))home();else if(q.equals("Schedule"))schedule();else if(q.equals("Study"))study();else if(q.equals("日本語"))jp();else settings();});n.addView(b,new LinearLayout.LayoutParams(0,60,1));}content.addView(n);}
    void title(String a,String b){TextView h=t(a,28);h.setTextColor(PURPLE);h.setTypeface(null,1);content.addView(h);content.addView(t(b,14));}
    int done(){int d=0;for(int i=0;i<tasks.length;i++)if(prefs.getBoolean("t"+i,false))d++;return d;}
    void home(){base();title("✨ GlowUp Schedule","Your routine, progress, and goals in one place.");
        LinearLayout c=card();c.addView(t("Today • "+done()+"/"+tasks.length+" tasks complete",18));
        ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);p.setMax(tasks.length);p.setProgress(done());c.addView(p,new LinearLayout.LayoutParams(-1,24));content.addView(c);
        content.addView(t("⏰ What should I do now?",20));content.addView(t(current(),16));
        Button s=new Button(this);s.setText("📋 Open today's schedule");s.setAllCaps(false);s.setOnClickListener(v->schedule());content.addView(s);
        Button st=new Button(this);st.setText("📚 Start studying");st.setAllCaps(false);st.setOnClickListener(v->study());content.addView(st);
        nav();}
    String current(){Calendar c=Calendar.getInstance();int now=c.get(Calendar.HOUR_OF_DAY)*60+c.get(Calendar.MINUTE);
        for(String[] x:tasks){String z=x[0].replace(" AM","").replace(" PM","");String[] a=z.split(":");int h=Integer.parseInt(a[0]);int m=Integer.parseInt(a[1]);if(x[0].contains("PM")&&h<12)h+=12;if(x[0].contains("AM")&&h==12)h=0;int start=h*60+m;if(now>=start&&now<start+60)return "Right now: "+x[1]+" • "+x[0];}
        return "You're between schedule blocks. Check your tasks and choose what you need next.";}
    void schedule(){base();title("🗓️ Daily Schedule","Tap a task when you finish it.");
        for(int i=0;i<tasks.length;i++){int k=i;CheckBox b=new CheckBox(this);b.setText(tasks[i][0]+"  •  "+tasks[i][1]);b.setTextColor(WHITE);b.setTextSize(15);b.setChecked(prefs.getBoolean("t"+i,false));
            b.setOnCheckedChangeListener((v,x)->prefs.edit().putBoolean("t"+k,x).apply());content.addView(b);}
        Button r=new Button(this);r.setText("Reset today's progress");r.setOnClickListener(v->{prefs.edit().clear().apply();schedule();});content.addView(r);nav();}
    void study(){base();title("📚 Study Hub","Practice at your own pace.");
        String[] a={"World History","Biology","Chemistry","Algebra","Geometry","10th Grade Grammar","10th Grade Reading"};
        for(String q:a){Button b=new Button(this);b.setText("📝 "+q);b.setAllCaps(false);b.setOnClickListener(v->Toast.makeText(this,q+" practice coming in V2!",Toast.LENGTH_SHORT).show());content.addView(b);}
        Button x=new Button(this);x.setText("⏱️ Start 25-minute focus session");x.setOnClickListener(v->Toast.makeText(this,"Focus session started!",Toast.LENGTH_SHORT).show());content.addView(x);nav();}
    void jp(){base();title("🇯🇵 Japanese Beginner","Your learning path starts here.");
        LinearLayout c=card();c.addView(t("⭐ Lesson 1 • Greetings • +10 XP",18));c.addView(t("① Hiragana  ② Greetings  ③ Numbers  ④ School",15));content.addView(c);
        content.addView(t("What does ありがとう mean?",20));String[] a={"Good morning","Thank you","Good night","Hello"};
        for(String q:a){Button b=new Button(this);b.setText(q);b.setAllCaps(false);b.setOnClickListener(v->Toast.makeText(this,q.equals("Thank you")?"Correct! +10 XP ⭐":"Try again 💜",Toast.LENGTH_SHORT).show());content.addView(b);}
        content.addView(t("🌸 Next: Hiragana • Introductions • Numbers • Colors • Food • Family • School • Grammar • Conversations",15));nav();}
    void settings(){base();title("⚙️ Settings","Customize your routine.");
        content.addView(t("🔔 Planned reminders",20));content.addView(t("5:00 AM Wake up\n4:30 PM Study\n7:00 PM Editing\n8:00 PM Movement\n9:00 PM Self-care\n10:00 PM Sleep",16));
        Button b=new Button(this);b.setText("Enable notifications");b.setOnClickListener(v->Toast.makeText(this,"Notifications are enabled when Android permission is granted.",Toast.LENGTH_LONG).show());content.addView(b);
        Button r=new Button(this);r.setText("Reset all progress");r.setOnClickListener(v->{prefs.edit().clear().apply();Toast.makeText(this,"Progress reset.",Toast.LENGTH_SHORT).show();});content.addView(r);nav();}
}